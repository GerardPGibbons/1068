

//Gerard Patrick Gibbons, Junior Year Computer Science Major.
//December 14, 2017
//This project was meant to test our skills when it comes to objects. It is to make a test.
package driver;


public class Driver {

    
    public static void main(String[] args) {
      
        String [] questions = new String[4];
        questions[0] = "spongebob";
        questions[1] = "patrick";
        questions[2] = "you";
        questions[3] = "Trump";
      
        Question [] qArray = new Question[3];
        qArray[0] = new ObjectiveQuestion(5, 4, 3, "Who is the best Student? ", "I am.");
        qArray[1] = new FillInTheBlankQuestion(3, 4, 2, "____ was the president of the United States", "Abraham Lincoln");
        qArray[2] =  new MultipleChoiceQuestion(3, 4, 3, "Who are you?", questions, "you");
        Test t1 = new Test(qArray);
        System.out.println(t1.toString());
        System.out.println("-----------Answer Sheet Below -----------------");
        System.out.println(t1.answerSheet());
    }
    
    }
    
