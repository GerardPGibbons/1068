
package driver;



public class FillInTheBlankQuestion extends Question{
    public String correctAnswer = "";
    public FillInTheBlankQuestion(int points, int diff, int answerspa, String questText, String correctAnswer)
    {
        this.points = points;
        this.difficulty = diff;
        this.answerSpace = answerspa;
        this.questionText = questText;
        this.correctAnswer = correctAnswer;
    }

    public String answerSheet()
    {
        int indexOne = 0;
        int indexTwo = 0;
        for(int i = 0; i < this.questionText.length(); i++)
        {
            if(this.questionText.charAt(i) == '_')
            {
                indexTwo = i;
                
            } 
        }
    String firstHalf = "";
    String secondHalf = "";
    
   
  
    for(int i = this.questionText.length() - 1; i > 0;  i --)
        {
            if(this.questionText.charAt(i) == '_');
            {
            indexOne = i;
            }
        
        }
     for (int i = 0; i < indexOne ; i ++)
    {
        firstHalf += this.questionText.charAt(i);
    }
     
    for(int i = indexTwo ;i < this.questionText.length();  i ++)
    {
        secondHalf += this.questionText.charAt(i);
    }
    return firstHalf + this.correctAnswer + secondHalf + "\n\n";
}
}

