
package driver;



public class MultipleChoiceQuestion extends Question {
    
    String correctAnswer = "";
    String [] possibleAnswers = new String [4];
   
    public MultipleChoiceQuestion(int points, int diff, int answerspa, String questText, String [] possible, String correctAnswer)
    {
        this.points = points;
        this.difficulty = diff;
        this.answerSpace = answerspa;
        this.questionText = questText;
        this.possibleAnswers = possible;
        this.correctAnswer = correctAnswer;
    }
    
    @Override
    public String toString()
    {
        
        return (this.questionText + "\n1. " + this.possibleAnswers[0] + "\n2. " + this.possibleAnswers[1] + "\n3. " + this.possibleAnswers[2] +
                "\n4. " + this.possibleAnswers[3]);
    }
    public String answerSheet()
    {
         String Answers = this.questionText + "\n";
         for(int i = 0; i < 4; i++)
         {
             Answers += (i+1);
             Answers += ". ";
         if(this.possibleAnswers[i].equals(this.correctAnswer))
         {
            Answers += "*** " + this.possibleAnswers[i] + "***";
         }
         else
         {
             Answers += this.possibleAnswers[i];
         }
         Answers += "\n";
         }
         return Answers;
    }
}

