
package driver;


public class ObjectiveQuestion extends Question{
        public String correctAnswer = "";
        public String answerSheet()
        {
            return this.questionText + "\n"  + "\nCorrect Answer: " + correctAnswer + "\n\n";
        }
        public ObjectiveQuestion(int points, int diff, int answerspa, String questText, String correctAnswer)
        {
            this.points = points;
            this.difficulty = diff;
            this.answerSpace = answerspa;
            this.questionText = questText;
            this.correctAnswer = correctAnswer;
        }
}
