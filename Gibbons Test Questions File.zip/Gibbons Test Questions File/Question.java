
package driver;


public class Question {
   public static final int MIN_DIFFICULTY = 0;
   public static final int MAX_DIFFICULTY = 10;
   public int points = 0;
   public int difficulty = MIN_DIFFICULTY;
   public int answerSpace = 0;
   public String questionText = "";
   public String answerSheet()
   {
       //adding this so the questions array in Test will be able to run.
       return "";
   }
   public String toString()
        {
            String spaces = "\n";
            String totalSpaces = "";
            for(int i = 0; i < this.answerSpace; i++)
            {
                totalSpaces += spaces;
            }
            return (this.questionText + totalSpaces);
        }
   
   
}