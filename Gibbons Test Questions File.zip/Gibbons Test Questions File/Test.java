
package driver;



public class Test {
    Question [] Questions = new Question[3];
    int totalPoints = 0;
    public Test(Question []q)
    {
        this.Questions = q;
      
    }
    @Override
    public String toString()
    {
        String printStuff = "";
        for(int i = 0; i < 3; i ++)
        {
            printStuff += this.Questions[i].toString();
        }
        return printStuff;
    }
    
    public String answerSheet()
    {
        String printStuff = "";
        for(int i = 0; i < 3; i ++)
        {
            printStuff += this.Questions[i].answerSheet();
        }
        return printStuff;
    }
}
